/* Needed Tools — loading, the same in every tool: a thin orange line along the top edge of the page,
   and a small status (the tiles, a label, a percentage) in the page's status row — #ntLoadSlot when the
   page has one (Add's queue row), or tucked into the bottom-left corner when it doesn't. Never over content.
   window.__neededLoad.start(label) / .set(f) / .done(). */
(function () {
  if (window.__neededLoad) return;
  const style = document.createElement('style');
  style.textContent = `
    .needed-edge { position: fixed; left: 0; right: 0; top: 0; height: 2px; z-index: 2147483000; pointer-events: none; opacity: 0; transition: opacity .3s ease; }
    .needed-edge.on { opacity: 1; }
    .needed-edge b { position: absolute; left: 0; top: 0; bottom: 0; width: 0; background: #F05A22; box-shadow: 0 0 10px rgba(240,90,34,.75); transition: width .3s cubic-bezier(0.23,1,0.32,1); }
    .needed-edge.unknown b { width: 28% !important; animation: nt-edge 1.3s cubic-bezier(0.45,0,0.55,1) infinite; }
    @keyframes nt-edge { from { transform: translateX(-100%); } to { transform: translateX(360%); } }
    .needed-status { display: inline-flex; align-items: center; gap: 8px; font: 500 13px Raleway, sans-serif; color: inherit; white-space: nowrap; opacity: 0; transition: opacity .2s ease; pointer-events: none; }
    .needed-status.on { opacity: 1; }
    .needed-status em { font: 700 10.5px 'Courier Prime', monospace; letter-spacing: .08em; font-style: normal; font-variant-numeric: tabular-nums; opacity: .6; }
    .needed-status.float { position: fixed; left: 16px; bottom: 14px; z-index: 2147483000; padding: 7px 12px 7px 10px; border-radius: 11px;
      background: rgba(255,255,255,.88); color: #141414; border: 1px solid rgba(18,22,28,.08); box-shadow: 0 10px 30px rgba(20,24,30,.14);
      -webkit-backdrop-filter: blur(20px); backdrop-filter: blur(20px); }
    html[data-theme=dark] .needed-status.float { background: rgba(24,25,28,.88); color: #f2f0ec; border-color: rgba(255,255,255,.09); box-shadow: 0 12px 34px rgba(0,0,0,.45); }
    .needed-status.done .nt-tiles i { animation: none; opacity: 1; background: #F05A22; }
    @media (prefers-reduced-motion: reduce) { .needed-edge.unknown b { animation: none; width: 100% !important; opacity: .5; } }
  `;
  (document.head || document.documentElement).appendChild(style);

  const edge = document.createElement('div');
  edge.className = 'needed-edge'; edge.innerHTML = '<b></b>';
  const status = document.createElement('span');
  status.className = 'needed-status'; status.setAttribute('role', 'status');
  status.innerHTML = '<span class="nt-tiles" aria-hidden="true"><i></i><i></i><i></i><i></i></span><span class="lbl"></span><em></em>';
  document.body.appendChild(edge);
  const place = () => {
    const slot = document.getElementById('ntLoadSlot');
    if (slot && slot.offsetParent) { status.classList.remove('float'); if (status.parentNode !== slot) slot.appendChild(status); }
    else { status.classList.add('float'); if (status.parentNode !== document.body) document.body.appendChild(status); }
  };
  let busy = 0, showT = null, hideT = null;
  const L = window.__neededLoad = {
    get busy() { return busy > 0; },
    start(label) {
      busy++; clearTimeout(hideT); status.classList.remove('done');
      status.querySelector('.lbl').textContent = label || 'Bringing it in';
      L.set(null);
      clearTimeout(showT); showT = setTimeout(() => { if (busy > 0) { place(); edge.classList.add('on'); status.classList.add('on'); } }, 250);   // quick jobs never flash it up
    },
    set(f) {
      const bar = edge.querySelector('b'), pct = status.querySelector('em');
      if (f == null || !isFinite(f)) { edge.classList.add('unknown'); pct.textContent = ''; return; }
      edge.classList.remove('unknown');
      const n = Math.max(0, Math.min(100, Math.round(f * 100)));
      bar.style.width = n + '%'; pct.textContent = n + '%';
    },
    done() {
      busy = Math.max(0, busy - 1);
      if (busy) return;
      clearTimeout(showT);
      if (edge.classList.contains('on')) {
        L.set(1); status.classList.add('done');
        hideT = setTimeout(() => { edge.classList.remove('on'); status.classList.remove('on'); }, 560);
      }
    },
  };
})();
