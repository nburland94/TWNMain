/* Needed Tools — Apple-style feel on every page and tool (Emil Kowalski's "apple-design" skill, applied).
   1. Response: feedback the instant you press, not when you let go (scale 0.97, 100ms). Uses the
      `scale` property, so it never fights a button's own transform (centring, the sliding lens).
   2. No tap delay, no grey tap flash.
   3. Things arrive from where they came: drawers slide in from their edge, menus grow from the top
      (anchored to the button that opened them) and materialise — blur + scale + fade together.
   4. Type: big titles tighten (negative tracking, tight leading); body text left alone. Low priority
      (:where), so every page's own type wins where it's been set on purpose.
   5. Respect the Mac's accessibility settings: Reduce motion (cross-fades, no slides or bounce),
      Reduce transparency (solid panels, no blur), Increase contrast (clear edges), and a visible
      keyboard focus ring.
   Loaded with glass.js and theme.js (Shell.swift). */
(function () {
  if (window.__neededApple) return;
  window.__neededApple = true;

  const EASE = 'cubic-bezier(0.23, 1, 0.32, 1)';          // critically damped feel: fast, no overshoot
  const PRESS = ':is(button, [role=button], .pill, .chip, .seg > *, .rd-ghost, .rd-ibtn, .exsrc, .pick, label.sw):not(:disabled):not([aria-disabled=true]):not(.nlens)';

  const css = `
/* 1 — response on press */
/* low priority: a page's own transitions win; elsewhere the press eases in 100ms */
:where(${PRESS}){transition:scale 100ms ease-out,background-color .15s ease,border-color .15s ease,color .15s ease,box-shadow .15s ease,opacity .15s ease}
${PRESS}:active{scale:0.97}
:is(.pick, .exsrc):active{scale:0.985}
/* the sidebar's rows are wide — any shrink there reads as a jump, so they don't move */
:is(aside, aside *, .card, .card *, .row, .hv, .psearch, #meBtn):active:not(#nt-x){scale:1!important}

/* 2 — no tap delay or flash */
:is(a, button, input, select, textarea, label, [role=button]){touch-action:manipulation;-webkit-tap-highlight-color:transparent}

/* 3 — spatial consistency + materialise */
@keyframes ntDrawerIn{from{translate:28px 0;opacity:0;filter:blur(6px)}to{translate:0 0;opacity:1;filter:blur(0)}}
@keyframes ntPopIn{from{scale:0.96;opacity:0;filter:blur(4px)}to{scale:1;opacity:1;filter:blur(0)}}
.drawer:not([hidden]){animation:ntDrawerIn .32s ${EASE}}
:is(.rd-pop, #sgColsMenu, .menu, .popover, [role=menu]):not([hidden]){transform-origin:top center;animation:ntPopIn .18s ${EASE}}

/* 4 — type: tighten as it grows */
:where(h1){letter-spacing:-0.02em;line-height:1.08}
:where(h2){letter-spacing:-0.012em;line-height:1.15}
:where(h3){letter-spacing:-0.005em;line-height:1.25}
:where(html){-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility;font-optical-sizing:auto}

/* 5 — accessibility */
:focus-visible{outline:2px solid #F05A22;outline-offset:2px}
:is(input, textarea, [contenteditable]):focus-visible{outline-offset:0}
@media (prefers-reduced-motion: reduce){
  *, *::before, *::after{animation-duration:.01ms!important;animation-iteration-count:1!important;scroll-behavior:auto!important;
    transition-property:opacity,color,background-color,border-color!important;transition-duration:.15s!important}
  ${PRESS}:active{scale:1}
}
@media (prefers-reduced-transparency: reduce){
  *{-webkit-backdrop-filter:none!important;backdrop-filter:none!important}
  :is(.toast, .needed-load, .qbar, .g, .nt-tip, .qtip, .rd-pop, .drawer, #sgColsMenu, .rd-panel){background:var(--rd-pop, var(--panel, #ffffff))!important}
}
@media (prefers-contrast: more){
  :is(.g, .rd-pop, .drawer, .pill, .chip, .seg, input, select, textarea){border-color:currentColor!important}
}
`;
  const add = () => {
    if (document.getElementById('nt-apple')) return;
    const s = document.createElement('style');
    s.id = 'nt-apple';
    s.textContent = css;
    (document.head || document.documentElement).appendChild(s);
  };
  if (document.head) add(); else document.addEventListener('DOMContentLoaded', add);

  /* A spring for anything that moves with you (critically damped by default; give it bounce only
     after a flick). Starts from where the thing is now and keeps its speed, so it can be grabbed
     and redirected mid-flight: ntSpring({from, to, velocity, response, damping, onUpdate}). */
  window.ntSpring = function ({ from, to, velocity = 0, response = 0.35, damping = 1, rest = 0.5, onUpdate, onDone }) {
    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduce) { onUpdate && onUpdate(to); onDone && onDone(); return { stop() {} }; }
    const k = Math.pow(2 * Math.PI / response, 2), c = 4 * Math.PI * damping / response;
    let x = from - to, v = velocity, last = performance.now(), raf = 0, stopped = false;
    const step = now => {
      if (stopped) return;
      const dt = Math.min(0.032, (now - last) / 1000); last = now;
      const a = -k * x - c * v; v += a * dt; x += v * dt;
      if (Math.abs(x) < rest && Math.abs(v) < rest * 20) { onUpdate && onUpdate(to); onDone && onDone(); return; }
      onUpdate && onUpdate(to + x);
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return { stop() { stopped = true; cancelAnimationFrame(raf); }, get value() { return to + x; }, get velocity() { return v; } };
  };
  /* Soft edges: the further past a boundary you drag, the less it follows. */
  window.ntRubberband = (over, dim, c = 0.55) => (over * dim * c) / (dim + c * Math.abs(over));
  /* Where a flick is heading (Apple's projection), to pick the snap point. */
  window.ntProject = (v, d = 0.998) => (v / 1000) * d / (1 - d);

  /* Grab a panel and flick it away. It follows the pointer 1:1 (rubber-banding the wrong way),
     and on release looks at where your flick was heading: far enough → it carries on out at your
     speed and closes; not far enough → it springs back. Clicks still work: nothing moves until
     you've dragged 10px in its direction. */
  window.ntFlick = function (el, { axis = 'x', handle = () => true, dismiss, onProgress }) {
    if (!el || el.__ntFlick) return; el.__ntFlick = true;
    let st = null, anim = null, ate = false;
    const set = v => { el.style.translate = v ? (axis === 'x' ? `${v}px 0` : `0 ${v}px`) : ''; onProgress && onProgress(Math.max(0, v) / size()); };
    const size = () => axis === 'x' ? el.offsetWidth : el.offsetHeight;
    el.addEventListener('pointerdown', e => {
      if (e.button !== 0 || e.target.closest('input, textarea, select, button, a, [contenteditable]') || !handle(e)) return;
      if (anim) { anim.stop(); anim = null; }
      const cur = parseFloat((el.style.translate || '0 0').split(' ')[axis === 'x' ? 0 : 1]) || 0;
      st = { x: e.clientX, y: e.clientY, base: cur, live: false, hist: [], id: e.pointerId };
    });
    window.addEventListener('pointermove', e => {
      if (!st || e.pointerId !== st.id) return;
      const dx = e.clientX - st.x, dy = e.clientY - st.y, d = axis === 'x' ? dx : dy, o = axis === 'x' ? dy : dx;
      if (!st.live) {
        if (Math.abs(d) < 10 || Math.abs(d) < Math.abs(o)) { if (Math.abs(o) > 10) st = null; return; }
        st.live = true; try { el.setPointerCapture(e.pointerId); } catch (err) {}
        el.style.willChange = 'translate'; document.documentElement.style.cursor = 'grabbing';
      }
      e.preventDefault();
      let v = st.base + d - (d > 0 ? 10 : -10);
      if (v < 0) v = window.ntRubberband(v, size());
      set(v);
      st.hist.push([v, performance.now()]); if (st.hist.length > 6) st.hist.shift();
    }, { passive: false });
    const end = () => {
      if (!st) return;
      const s = st; st = null;
      if (!s.live) return;
      ate = true; setTimeout(() => { ate = false; }, 0);
      document.documentElement.style.cursor = ''; el.style.willChange = '';
      const h = s.hist, a = h[0] || [0, 0], z = h[h.length - 1] || [0, 0];
      const pos = z[0], vel = z[1] > a[1] ? (z[0] - a[0]) / ((z[1] - a[1]) / 1000) : 0;
      const W = size(), lands = pos + window.ntProject(vel);
      if (lands > W * 0.45) {
        anim = window.ntSpring({ from: pos, to: W + 40, velocity: vel, response: 0.3, damping: 1, rest: 4, onUpdate: set,
          onDone: () => { anim = null; dismiss && dismiss(); setTimeout(() => set(0), 320); } });
      } else {
        anim = window.ntSpring({ from: pos, to: 0, velocity: vel, response: 0.3, damping: Math.abs(vel) > 600 ? 0.8 : 1, onUpdate: set, onDone: () => { anim = null; set(0); } });
      }
    };
    window.addEventListener('pointerup', end);
    window.addEventListener('pointercancel', end);
    el.addEventListener('click', e => { if (ate) { e.stopPropagation(); e.preventDefault(); } }, true);
  };

  // Wire up the panels that slide: Shots' References drawer (flick right) and Design's sheets (flick down).
  const wire = () => {
    const drawer = document.getElementById('drawer'), close = document.getElementById('drawerClose');
    if (drawer && close) window.ntFlick(drawer, { axis: 'x', dismiss: () => close.click() });
    const sheet = document.getElementById('sheet'), veil = document.getElementById('veil');
    if (sheet && veil && veil.classList.contains('veil')) window.ntFlick(sheet, {
      axis: 'y',
      handle: e => e.clientY - sheet.getBoundingClientRect().top < 72,
      onProgress: p => { veil.style.transition = p > 0 ? 'none' : ''; veil.style.opacity = p > 0 ? String(1 - Math.min(1, p) * 0.6) : ''; },
      dismiss: () => { veil.dispatchEvent(new MouseEvent('mousedown', { bubbles: true })); setTimeout(() => { veil.style.opacity = ''; }, 320); }
    });
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', wire); else wire();
})();
