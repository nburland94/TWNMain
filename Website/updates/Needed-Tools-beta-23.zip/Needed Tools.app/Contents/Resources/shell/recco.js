/* Recco Beta — Option A. All media and AI results come from the native worker. */
(()=>{
 if(!window.webkit?.messageHandlers?.shell)return;
 const call=(action,args={})=>window.webkit.messageHandlers.shell.postMessage({action,...args});
 const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const launcher=document.createElement('button');launcher.id='reccoLaunch';launcher.innerHTML='Recco <small>NEW · BETA</small>';launcher.type='button';
 const tabBar=document.getElementById('exTabs');if(tabBar){const row=document.createElement('div');row.className='rcExploreBar';tabBar.before(row);row.append(tabBar,launcher)}else document.getElementById('explore').appendChild(launcher);
 const panel=document.createElement('aside');panel.id='reccoPanel';panel.hidden=true;panel.setAttribute('aria-label','Recco Beta');
 panel.innerHTML=`<header><h2>Recco</h2><span class="rcBeta">BETA</span><span id="rcProject"></span><button id="rcHide" aria-label="Hide Recco">−</button><div id="rcBriefLine"></div></header>
 <nav aria-label="Recco sections"><button data-rc-tab="brief" class="on">Brief</button><button data-rc-tab="sources">Sources</button><button data-rc-tab="results">Reccos</button><button data-rc-tab="saved">Grabbed</button></nav>
 <section id="rcBrief"><label for="rcCopy">TREATMENT OR BRIEF</label><textarea id="rcCopy" maxlength="24000" placeholder="Paste your treatment, brief or visual direction…"></textarea><div class="rcSettings"><label>Assistant<select id="rcProvider"><option>Automatic</option><option>Codex</option><option>Claude</option></select></label><label>Images<select id="rcCount"><option>10</option><option>25</option><option>50</option><option>100</option></select></label></div><p id="rcSource">Choose one or more open Explore tabs in Sources. Your image count is shared across them.</p><p class="rcHelp">Your brief, image descriptions and numbered previews go to your signed-in assistant. Search support varies by site; open a results page if its search control is unavailable. The app stays open while Recco works.</p><button id="rcStart" class="rcPrimary">Find references ↗</button><p id="rcSetup"></p><div id="rcConnect"></div><label class="rcTagToggle"><input type="checkbox" id="rcAutoTags" checked> Auto-tag all Vault assets</label><p id="rcTagStatus"></p></section>
 <section id="rcSources" hidden><h3>Search across your tabs</h3><p>One brief. One image count. Two sources at a time.</p><div id="rcSourceList"></div><div class="rcPager"><button id="rcSourcesPrev" aria-label="Previous sources">←</button><span id="rcSourcesPage"></span><button id="rcSourcesNext" aria-label="Next sources">→</button></div><p id="rcSourceCount"></p></section>
 <section id="rcResults" hidden><div class="rcStatusRow"><span id="rcStatus" role="status" aria-live="polite"></span><button id="rcSelect">Select all</button></div><div id="rcSheet" aria-label="References by brief section"></div></section>
 <footer><span id="rcSelected">0 selected</span><button id="rcStop" hidden>Stop search</button><button id="rcGrab" class="rcPrimary" disabled>Grab selected</button></footer><div id="rcError" role="alert" hidden></div>`;
 document.body.appendChild(panel);const $=id=>document.getElementById(id);let state={results:[]},tab='brief',page=0,selected=new Set(),signature='',polling=false,sourceIDs=new Set(),sourcesTouched=false,sourcePage=0,sourceSignature='',sectionID='';
 function error(s){$('rcError').textContent=s||'';$('rcError').hidden=!s}
 function show(on){const hc=document.getElementById('hcRecco'),b=hc&&hc.offsetParent&&!document.body.classList.contains('hcBrowsing')?hc:launcher,r=b.getBoundingClientRect(),reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
 panel.style.transformOrigin=`${Math.round(r.left+r.width/2-14)}px ${Math.round(r.top+r.height/2-14)}px`;clearTimeout(show.t);
 call('reccoPlate',{open:!!on}).catch(()=>{}); if(on){if(tab==='brief')switchTab('results');panel.classList.remove('rcClosing');panel.hidden=false;document.body.classList.add('recco-open');b.setAttribute('aria-expanded','true');}
 else if(!panel.hidden){panel.classList.add('rcClosing');document.body.classList.remove('recco-open');b.setAttribute('aria-expanded','false');show.t=setTimeout(()=>{panel.hidden=true;panel.classList.remove('rcClosing');window.__browseFrame?.();},reduce?0:300);}
 requestAnimationFrame(()=>window.__browseFrame?.());}
 launcher.onclick=()=>show(panel.hidden);window.__reccoBrief=(text,name)=>{const c=$('rcCopy');c.value=text;c.dispatchEvent(new Event('input',{bubbles:true}));c.dataset.file=name||'';const l=panel.querySelector('label[for=rcCopy]');if(l)l.dataset.file=name?('Brief · '+name):'';c.scrollTop=0;};$('rcHide').onclick=()=>show(false);
 function visible(){return state.results.filter(r=>tab!=='saved'||r.saved)}
 function switchTab(t){tab=t;page=0;panel.querySelectorAll('[data-rc-tab]').forEach(b=>b.classList.toggle('on',b.dataset.rcTab===t));$('rcBrief').hidden=t!=='brief';$('rcResults').hidden=!['results','saved'].includes(t);$('rcSources').hidden=t!=='sources';render()}
 panel.querySelector('nav').onclick=e=>{const b=e.target.closest('[data-rc-tab]');if(b)switchTab(b.dataset.rcTab)};
 function render(){
 renderSources();const rows=visible(),groups=new Map();
 for(const r of rows){const key=r.sectionID||r.section||'overall';if(!groups.has(key))groups.set(key,{name:r.section||'Overall theme',excerpt:r.excerpt||'',rows:[]});groups.get(key).rows.push(r)}
 const ordered=[...groups.entries()].sort((a,b)=>{const rank=id=>{const i=(state.sections||[]).findIndex(s=>s.id===id);return i<0?999:i};return rank(a[0])-rank(b[0])}).map(([,group])=>group);
 const html=ordered.map(g=>`<section class="rcSectionBlock"><header><h3>${esc(g.name)}</h3><span>${g.rows.length}</span><p title="${esc(g.excerpt)}">${esc(g.excerpt||'Overall visual direction')}</p></header><div class="rcSectionImages">${g.rows.map(r=>`<article><div class="rcImageWrap"><button class="rcImage" data-preview="${esc(r.id)}" aria-label="Preview ${esc(r.section||'reference')} full screen"><img src="${esc(r.image)}" alt="${esc(r.reason)}" loading="lazy"></button><button class="rcPick ${selected.has(r.id)?'selected':''}" data-id="${esc(r.id)}" aria-pressed="${selected.has(r.id)}" aria-label="${selected.has(r.id)?'Deselect':'Select'} reference">${selected.has(r.id)?'✓':'＋'}</button></div><button class="rcReason" data-source="${esc(r.id)}" title="${esc(r.reason)} — open source">${esc(r.reason)} ↗</button><button class="rcInfo" data-info="${esc(r.id)}" title="${esc((r.excerpt?'From: '+r.excerpt:'Overall theme: '+r.section)+' — '+r.reason)}" aria-label="Why this reference?">ⓘ ${esc(r.sourceTitle||'Source')}</button>${r.saved?'<small>Grabbed</small>':''}</article>`).join('')}</div></section>`).join('')||'<div class="rcEmpty">'+(tab==='saved'?'Your grabbed recommendations appear here.':state.running?'Recco is working in the background…':'Drop or paste a brief on the left to start.')+'</div>';
 if($('rcSheet')._html!==html){const scroll=$('rcSheet').scrollTop;$('rcSheet').innerHTML=html;$('rcSheet')._html=html;$('rcSheet').scrollTop=scroll;}
 $('rcStatus').textContent=state.status||'';$('rcStop').hidden=!state.running;$('rcStart').disabled=!!state.running||!sourceIDs.size;
 $('rcProject').textContent=state.project||'';$('rcSelected').textContent=selected.size+' selected';$('rcGrab').disabled=!selected.size;
 launcher.innerHTML='Recco <small>'+(state.running?state.results.length+' / '+state.target:'NEW · BETA')+'</small>';
 // Round 63: tabs say how many; the brief sits under the name in one line
 const savedN=state.results.filter(r=>r.saved).length,briefTxt=$('rcCopy').value.trim();
 const lab={brief:'Brief'+(briefTxt?'<i>✓</i>':''),sources:'Sources<i>'+sourceIDs.size+'</i>',results:'Reccos<i>'+state.results.length+'</i>',saved:'Grabbed<i>'+savedN+'</i>'};
 panel.querySelectorAll('[data-rc-tab]').forEach(b=>{const h=lab[b.dataset.rcTab];if(h&&b.innerHTML!==h)b.innerHTML=h;});
 const bl=$('rcBriefLine'),bh=briefTxt?'<b>Brief'+(state.project?' · '+esc(state.project):'')+'</b>'+esc(briefTxt.slice(0,220)):'';if(bl&&bl.innerHTML!==bh)bl.innerHTML=bh;
 $('rcGrab').textContent=selected.size?'Grab '+selected.size+(state.project?' → '+state.project:''):'Grab selected';
 }

 const detail=document.createElement('div');detail.id='rcDetail';detail.hidden=true;detail.innerHTML='<button id="rcDetailClose" aria-label="Close reference details">×</button><h3 id="rcDetailTitle"></h3><p id="rcDetailText"></p><button id="rcDetailSource"></button>';panel.append(detail);$('rcDetailClose').onclick=()=>detail.hidden=true;
 $('rcCopy').addEventListener('input',()=>render());
 // Round 63d: one long page of reccos — pinch (or ⌘-scroll) to see more or fewer at once
 {const sh=$('rcSheet');let tile=180,start=180;try{tile=+localStorage.getItem('recco.tile')||180}catch(e){}
  const setTile=w=>{tile=Math.max(90,Math.min(440,w));panel.style.setProperty('--rc-tile',Math.round(tile)+'px');try{localStorage.setItem('recco.tile',Math.round(tile))}catch(e){}};setTile(tile);
  sh.addEventListener('wheel',e=>{if(!e.ctrlKey&&!e.metaKey)return;e.preventDefault();setTile(tile*Math.exp(-e.deltaY*.01));},{passive:false});
  sh.addEventListener('gesturestart',e=>{e.preventDefault();start=tile;});
  sh.addEventListener('gesturechange',e=>{e.preventDefault();setTile(start*e.scale);});}
 $('rcConnect').addEventListener('click',async e=>{const t=e.target.closest('button');if(!t)return;if(t.id==='rcClaudeStop')await call('claudeConnect',{cancel:true});else await call('claudeConnect');signature='';poll();});

 function renderSources(){
 const jobs=state.sources||[],available=[...(state.tabs||[])];if(state.running)jobs.forEach(j=>{if(!available.some(t=>t.id===j.id))available.push({id:j.id,title:j.title,host:'Background source'})});const pages=Math.max(1,1);sourcePage=Math.max(0,Math.min(sourcePage,pages-1));
 const sig=JSON.stringify([available,jobs,[...sourceIDs],sourcePage,state.running]);
 if(sig!==sourceSignature){sourceSignature=sig;$('rcSourceList').innerHTML=available.map(t=>{const job=jobs.find(j=>j.id===t.id);return `<label class="rcSourceRow"><input type="checkbox" data-source-id="${esc(t.id)}" ${sourceIDs.has(t.id)?'checked':''} ${state.running?'disabled':''}><span><strong>${esc(t.title)}</strong><small>${esc(job?.status||t.host)}</small></span></label>`}).join('')||'<p>Open a reference website in an Explore tab to include it.</p>';}
 $('rcSourcesPage').textContent=(sourcePage+1)+' / '+pages;$('rcSourcesPrev').disabled=!sourcePage;$('rcSourcesNext').disabled=sourcePage>=pages-1;$('rcSourceCount').textContent=sourceIDs.size+' tabs selected';$('rcSource').textContent=sourceIDs.size+' source tabs · '+$('rcCount').value+' images total. Choose tabs in Sources.';
 }
 $('rcSourcesPrev').onclick=()=>{sourcePage--;renderSources()};$('rcSourcesNext').onclick=()=>{sourcePage++;renderSources()};
 $('rcSourceList').onchange=e=>{const id=e.target.dataset.sourceId;if(!id)return;sourcesTouched=true;e.target.checked?sourceIDs.add(id):sourceIDs.delete(id);render()};$('rcCount').onchange=renderSources;

 $('rcSheet').onclick=e=>{const preview=e.target.closest('[data-preview]');if(preview){openPreview(preview.dataset.preview);return;}const info=e.target.closest('[data-info]');if(info){const r=state.results.find(r=>r.id===info.dataset.info);if(r){$('rcDetailTitle').textContent=r.section||'Overall theme';$('rcDetailText').textContent=(r.excerpt?'“'+r.excerpt+'”':'Inferred from the overall brief.')+'\n\n'+r.reason;$('rcDetailSource').textContent=r.sourceTitle||'Open source';$('rcDetailSource').onclick=()=>{call('browse',{url:r.page});detail.hidden=true;show(false)};detail.hidden=false;}return;}const b=e.target.closest('[data-id]');if(b){selected.has(b.dataset.id)?selected.delete(b.dataset.id):selected.add(b.dataset.id);render()}const src=e.target.closest('[data-source]');if(src){const r=state.results.find(r=>r.id===src.dataset.source);if(r?.page)call('browse',{url:r.page})}};
 $('rcSelect').onclick=()=>{const rows=visible(),all=rows.every(r=>selected.has(r.id));rows.forEach(r=>all?selected.delete(r.id):selected.add(r.id));render()};

 const preview=document.createElement('dialog');preview.id='rcPreview';preview.setAttribute('aria-label','Full-screen reference preview');preview.innerHTML='<header><span id="rcPreviewTitle"></span><button id="rcPreviewClose" aria-label="Close preview">Close ×</button></header><div class="rcPreviewMedia"><img id="rcPreviewImage" alt=""></div><footer><button id="rcPreviewPrev" aria-label="Previous reference">←</button><span id="rcPreviewPosition"></span><button id="rcPreviewNext" aria-label="Next reference">→</button><span id="rcPreviewStatus" role="status"></span><button id="rcPreviewPick">Select</button></footer>';document.body.append(preview);
 let previewID='',previewToken=0,previewFocus=null;
 async function openPreview(id){const r=state.results.find(r=>r.id===id);if(!r)return;previewID=id;const token=++previewToken;if(!preview.open){previewFocus=document.activeElement;document.body.classList.add('recco-preview-open');window.__browseFrame?.();preview.showModal();}
 $('rcPreviewImage').src=r.image;$('rcPreviewImage').alt=r.reason||'Reference';$('rcPreviewTitle').textContent=(r.section||'Overall theme')+' · '+(r.sourceTitle||'');$('rcPreviewStatus').textContent='Loading original…';previewControls();
 try{const result=await call('reccoPreview',{id});if(token!==previewToken||!preview.open)return;if(result.ok&&result.image){$('rcPreviewImage').src=result.image;$('rcPreviewStatus').textContent='';}else $('rcPreviewStatus').textContent='Original unavailable — showing thumbnail.';}catch{if(token===previewToken)$('rcPreviewStatus').textContent='Original unavailable — showing thumbnail.';}}
 function previewControls(){const rows=visible(),i=rows.findIndex(r=>r.id===previewID);$('rcPreviewPosition').textContent=(i+1)+' / '+rows.length;$('rcPreviewPrev').disabled=i<=0;$('rcPreviewNext').disabled=i<0||i>=rows.length-1;$('rcPreviewPick').textContent=selected.has(previewID)?'Selected ✓':'Select to grab';$('rcPreviewPick').setAttribute('aria-pressed',String(selected.has(previewID)));}
 function closePreview(){previewToken++;preview.close();$('rcPreviewImage').removeAttribute('src');document.body.classList.remove('recco-preview-open');window.__browseFrame?.();if(previewFocus?.isConnected)previewFocus.focus();}
 function stepPreview(n){const rows=visible(),i=rows.findIndex(r=>r.id===previewID);if(rows[i+n])openPreview(rows[i+n].id);}
 $('rcPreviewClose').onclick=closePreview;preview.oncancel=e=>{e.preventDefault();closePreview()};$('rcPreviewPrev').onclick=()=>stepPreview(-1);$('rcPreviewNext').onclick=()=>stepPreview(1);$('rcPreviewPick').onclick=()=>{selected.has(previewID)?selected.delete(previewID):selected.add(previewID);render();previewControls()};
 window.addEventListener('keydown',e=>{if(!preview.open)return;if(['Escape','ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();e.stopImmediatePropagation();if(e.key==='Escape')closePreview();else stepPreview(e.key==='ArrowLeft'?-1:1)}},true);
 $('rcStart').onclick=async()=>{error('');$('rcStart').disabled=true;try{const r=await call('reccoStart',{brief:$('rcCopy').value,provider:$('rcProvider').value,count:+$('rcCount').value,sourceIDs:[...sourceIDs]});if(!r.ok){error(r.error);return}state=r;selected.clear();switchTab('results')}catch(e){error('Could not start Recco. Please try again.')}finally{$('rcStart').disabled=!!state.running}};
 $('rcAutoTags').onchange=async()=>{await call('autoTagEnabled',{enabled:$('rcAutoTags').checked});await poll()};
 $('rcStop').onclick=async()=>{state=await call('reccoStop');render()};
 $('rcGrab').onclick=async()=>{const ids=[...selected];$('rcGrab').disabled=true;try{const r=await call('reccoGrab',{ids});if(!r.ok)error(r.error);else ids.forEach(id=>selected.delete(id));signature='';await poll()}catch(e){error('Could not save those references. Try again.')}finally{render()}};
 async function poll(){if(polling)return;polling=true;try{const r=await call('reccoState');const sig=JSON.stringify(r);state=r;state.results=state.results||[];const available=new Set((r.tabs||[]).map(t=>t.id));sourceIDs=new Set([...sourceIDs].filter(id=>available.has(id)));if(!sourcesTouched&&!sourceIDs.size){const current=(r.tabs||[]).find(t=>t.active);if(current)sourceIDs.add(current.id);}if(sig!==signature){signature=sig;render()}
 $('rcAutoTags').checked=!!r.tagging?.enabled;$('rcTagStatus').textContent=(r.tagging?.status||'')+' '+(r.tagging?.pending||0)+' pending.';
 const options=[...$('rcProvider').options];options.forEach(o=>o.disabled=o.value==='Automatic'?!r.autoEngine:!r[o.value.toLowerCase()]);if($('rcProvider').selectedOptions[0]?.disabled){const enabled=options.find(o=>!o.disabled);if(enabled)$('rcProvider').value=enabled.value}
 $('rcSetup').textContent=!r.codex&&!r.claude?'Install and sign in to Codex CLI or Claude Code to enable Recco. The desktop MCP connection alone cannot start a run.':!r.claude?'Codex is available. To use Claude, install Claude Code: in Terminal, run  curl -fsSL https://claude.ai/install.sh | bash  then type  claude  once to sign in, and reopen Needed Tools.':'';

 // Round 63: Connect Claude — one button, no Terminal
 const cc=r.claudeConnect||{},busy=['installing','signing','testing'].includes(cc.phase);
 const ch=cc.ready?'<span class="rcOk">✓ Claude connected</span><button type="button" id="rcClaudeAgain" class="rcLink">Sign in again</button>'
   :`<button type="button" id="rcClaudeGo" class="rcPrimary rcConnectBtn" ${busy?'disabled':''}>${busy?(cc.phase==='installing'?'Installing Claude Code…':cc.phase==='signing'?'Waiting for your sign-in…':'Checking…'):(cc.installed?'Sign in to Claude':'Connect Claude')}</button>${busy?'<button type="button" id="rcClaudeStop" class="rcLink">Cancel</button>':''}`;
 const cm=cc.message?'<p class="rcConnectMsg">'+esc(cc.message)+'</p>':(!cc.ready?'<p class="rcConnectMsg">Uses your own Claude plan (Pro or Max). Installs Claude Code if needed and opens the Claude sign-in in your browser — no Terminal.</p>':'');
 if($('rcConnect').dataset.h!==ch+cm){$('rcConnect').dataset.h=ch+cm;$('rcConnect').innerHTML='<div class="rcConnectRow">'+ch+'</div>'+cm;}
 $('rcSetup').textContent='';
 }catch{}finally{polling=false}}
 setInterval(poll,1500);poll();
})();
