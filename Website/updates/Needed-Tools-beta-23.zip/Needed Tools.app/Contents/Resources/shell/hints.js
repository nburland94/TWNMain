/* Needed Tools — the walkthrough inside each tool.
   Small liquid-glass notes beside the real controls, one at a time, with a
   soft ring round what to click. Steps whose control isn't on screen yet
   (Grab's "Grab this frame" before a film is in) wait and appear when it is.
   Every step is shown, in order; one whose control isn't on screen yet points
   to where it will appear. It runs each time you open the tool — ✕ closes it
   for this visit — until "Don't show again". ? replays it. */
(function () {
  if (window.__neededHints) return;
  // [control, title, note, where to point if the control isn't on screen yet, when it appears]
  // Redesign (Oct 2026): fewer, shorter notes — a title and one line each.
  const TOURS = {
    'neededvault:': [
      ['#linkInput', 'Paste a link', 'YouTube or Instagram — it plays right here.'],
      ['#addToVault', 'Add files', 'Or drop them anywhere on this window.'],
      ['#grabBtn', 'Grab a still', 'Press G. The arrow keys step a frame.', '#linkInput', 'Once something is playing'],
      ['#inBtn2', 'Make a GIF or clip', 'I to start, O to end.', '#linkInput', 'Once something is playing'],
      ['#exportBtn', 'Save', 'Into this project’s Vault folder.'],
    ],
    'neededshots:': [
      ['#beatsPanel', 'Paste your beats', 'Each line becomes a shot.'],
      ['.refcell .add', 'Add references', 'Stills from this project.'],
      ["#tabs button[data-tab='preview']", 'Preview', 'Check the page before you export.'],
      ['#exportBtn', 'Export', 'The PDF files into this project.'],
    ],
    'neededsort:': [
      ['#addCard', 'Add a card', 'Camera and sound, together.'],
      ['#scanBtn', 'Scan', 'Clips group into scenes by time.'],
      ['#destBtn', 'Where it goes', 'Choose where the folders are made.', '#scanBtn', 'After you scan'],
      ['#goBtn', 'Sort', 'Every file copied and checked.'],
    ],
    'neededgrab:': [
      ['#drop', 'Drop in a film', 'Or choose one.'],
      ['#grabBtn', 'Grab a still', 'Press G. The arrow keys step a frame.', '#drop', 'Once a film is in'],
      ['#inBtn2', 'Make a GIF or clip', 'I to start, O to end.', '#drop', 'Once a film is in'],
      ['#exportBtn', 'Save', 'Into this project’s Grab folder.'],
    ],
    'neededcredit:': [
      ['#drop', 'Drop the call sheet', 'Or paste the crew list.'],
      ['#readBtn', 'Read it', 'Names and roles, by department.'],
      ['#copyBtn', 'Copy', 'Ready to paste into your post.'],
    ],
    'neededpay:': [
      ['#newInvoiceBtn', 'Make an invoice', 'Pick the client, add the work.'],
      ['#sendBtn', 'Send it', 'From your own email, PDF attached.', '#newInvoiceBtn', 'On an invoice'],
    ],
  };
  const steps = TOURS[location.protocol];
  if (!steps) return;
  const KEY = 'needed.tour';
  const load = () => { try { return JSON.parse(localStorage.getItem(KEY) || '{}'); } catch (e) { return {}; } };
  const store = s => { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) { /* fine */ } };
  let state = load();                               // { off: true } once "Don't show again"
  state.done = [];                                  // each time a tool opens, the walkthrough starts from the top
  let dismissed = false;                            // ✕: gone for now, back next time

  const css = document.createElement('style');
  css.textContent = `
    html:not([data-theme=dark]){--tip-bg:rgba(250,250,252,0.9);--tip-line:rgba(255,255,255,0.9);--tip-arrow:#f8f9fb;--tip-text:#121417;--tip-dim:#4f5760;--tip-faint:#7c848d;--tip-dot:rgba(18,22,28,0.14);--tip-hover:rgba(18,22,28,0.06);--tip-shadow:rgba(20,24,30,0.22);--tip-acc:#F05A22;--tip-white:#ffffff}
    html[data-theme=dark]{--tip-bg:rgba(22,24,29,0.9);--tip-line:rgba(255,255,255,0.09);--tip-arrow:#17191e;--tip-text:#e4e8ec;--tip-dim:rgba(228,232,236,0.72);--tip-faint:rgba(228,232,236,0.45);--tip-dot:rgba(255,255,255,0.16);--tip-hover:rgba(255,255,255,0.07);--tip-shadow:rgba(0,0,0,0.6);--tip-acc:#F05A22;--tip-white:#ffffff}
    K .nt-tip{position:fixed;z-index:95;width:300px;box-sizing:border-box;border-radius:16px;padding:16px;font:13px/1.45 Raleway,sans-serif;color:var(--tip-text);
      background:var(--tip-bg);border:1px solid var(--tip-line);box-shadow:0 24px 60px var(--tip-shadow);
      -webkit-backdrop-filter:blur(40px) saturate(1.6);backdrop-filter:blur(40px) saturate(1.6);
      opacity:0;transform:translateY(6px) scale(0.98);transition:opacity .28s cubic-bezier(0.23,1,0.32,1),transform .28s cubic-bezier(0.23,1,0.32,1)}
    K .nt-tip.on{opacity:1;transform:none}
    K .nt-tip b{display:block;font-weight:700;font-size:15px;margin-bottom:4px;padding-right:24px}
    K .nt-tip p{margin:0;color:var(--tip-dim)}
    K .nt-tip .x{position:absolute;right:10px;top:10px;width:24px;height:24px;border:none;border-radius:6px;background:none;font-size:13px;color:var(--tip-faint);cursor:pointer}
    K .nt-tip .x:hover{background:var(--tip-hover)}
    K .nt-tip .foot{display:flex;align-items:center;gap:6px;margin-top:14px}
    K .nt-tip .dots{display:flex;align-items:center;gap:5px;margin-right:auto}
    K .nt-tip .dots i{width:6px;height:6px;border-radius:3px;background:var(--tip-dot);transition:width .25s}
    K .nt-tip .dots i.on{width:16px;background:var(--tip-acc)}
    K .nt-tip button.b{height:30px;border:none;border-radius:15px;padding:0 13px;font:600 12.5px Raleway,sans-serif;cursor:pointer;background:none;color:var(--tip-dim)}
    K .nt-tip button.b:hover{background:var(--tip-hover)}
    K .nt-tip button.go{background:var(--tip-acc);color:var(--tip-white)}
    K .nt-tip button.go:hover{filter:brightness(1.07);background:var(--tip-acc)}
    K .nt-tip label{display:flex;align-items:center;gap:6px;margin-top:10px;font-size:11.5px;color:var(--tip-faint);cursor:pointer}
    K .nt-tip label input{accent-color:#F05A22;width:12px;height:12px}
    K .nt-tip::before{content:'';position:absolute;width:14px;height:14px;transform:rotate(45deg);background:var(--tip-arrow);border:1px solid var(--tip-line);left:var(--ax,28px)}
    K .nt-tip.below::before{top:-8px;border-right:none;border-bottom:none}
    K .nt-tip.above::before{bottom:-8px;border-left:none;border-top:none}
    K .nt-ring{position:fixed;z-index:94;border-radius:12px;pointer-events:none;box-shadow:0 0 0 2px rgba(240,90,34,0.9),0 0 0 7px rgba(240,90,34,0.16);
      transition:all .3s cubic-bezier(0.23,1,0.32,1);animation:ntpulse 1.8s cubic-bezier(0.23,1,0.32,1) infinite}
    @keyframes ntpulse{0%{box-shadow:0 0 0 2px rgba(240,90,34,0.9),0 0 0 0 rgba(240,90,34,0.35)}100%{box-shadow:0 0 0 2px rgba(240,90,34,0.9),0 0 0 12px rgba(240,90,34,0)}}
    @media (prefers-reduced-motion:reduce){K .nt-tip,K .nt-ring{transition:none;animation:none}}
  `.replace(/K /g, ':is(html:not([data-theme=dark-keep]):not([data-nt-keep])) ');
  document.head.appendChild(css);

  const visible = el => { if (!el) return false; const r = el.getBoundingClientRect(), s = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none' && !el.closest('[hidden]'); };
  let tip = null, ring = null, at = -1;
  function close() {
    if (tip) { tip.remove(); tip = null; }
    if (ring) { ring.remove(); ring = null; }
    at = -1;
  }
  function place(el) {
    if (!tip) return;
    const r = el.getBoundingClientRect(), W = window.innerWidth, H = window.innerHeight, tw = tip.offsetWidth, th = tip.offsetHeight;
    const below = r.bottom + th + 18 < H || r.top < th + 18;
    const left = Math.max(12, Math.min(W - tw - 12, r.left));
    tip.style.left = left + 'px';
    tip.style.top = (below ? r.bottom + 14 : r.top - th - 14) + 'px';
    tip.classList.toggle('below', below); tip.classList.toggle('above', !below);
    tip.style.setProperty('--ax', Math.max(16, Math.min(tw - 30, r.left + Math.min(r.width, 60) / 2 - left - 7)) + 'px');
    if (ring) Object.assign(ring.style, { left: r.left - 5 + 'px', top: r.top - 5 + 'px', width: r.width + 10 + 'px', height: r.height + 10 + 'px' });
  }
  function show(i) {
    const [sel, title, text, fallback, when] = steps[i];
    let el = document.querySelector(sel), later = false;
    if (!visible(el) && fallback) { el = document.querySelector(fallback); later = true; }   // not here yet: say where and when
    if (!visible(el)) return false;
    close(); at = i;
    const r = el.getBoundingClientRect();
    if (r.top < 60 || r.bottom > window.innerHeight - 60) el.scrollIntoView({ block: 'center', behavior: 'smooth' });
    ring = document.createElement('div'); ring.className = 'nt-ring'; document.body.appendChild(ring);
    tip = document.createElement('div'); tip.className = 'nt-tip'; tip.setAttribute('role', 'dialog'); tip.setAttribute('aria-label', title);
    const hasBack = i > 0;
    const last = !steps.some((s, j) => j > i && !state.done.includes(s[0]));
    tip.innerHTML = `<button class="x" aria-label="Close">\u2715</button><b></b><p></p>
      <div class="foot"><span class="dots">${steps.map((x, j) => `<i${j === i ? ' class="on"' : ''}></i>`).join('')}</span>${hasBack ? '<button class="b back">Back</button>' : ''}
        <button class="b go">${last ? 'Got it' : 'Next'}</button></div>
      <label><input type="checkbox"> Don\u2019t show again</label>`;
    tip.querySelector('b').textContent = title;
    tip.querySelector('p').textContent = later ? `${when}: ${text.charAt(0).toLowerCase()}${text.slice(1)}` : text;
    document.body.appendChild(tip);
    place(el);
    requestAnimationFrame(() => tip && tip.classList.add('on'));
    tip.querySelector('.x').onclick = () => { dismissed = true; close(); };
    tip.querySelector('.go').onclick = () => {
      if (!state.done.includes(sel)) state.done.push(sel);
      store(state); close(); next();
    };
    const back = tip.querySelector('.back');
    if (back) back.onclick = () => { state.done = state.done.filter(s => s !== steps[i - 1][0]); show(i - 1); };
    tip.querySelector('input').onchange = e => { state.off = e.target.checked; store(state); if (state.off) close(); };
    return true;
  }
  // Strictly in order: the next step not yet done — and if its control isn't on
  // screen yet (a scene before you've scanned), wait for it rather than skipping ahead.
  function next() {
    if (state.off || dismissed || tip || document.visibilityState !== 'visible') return;
    const i = steps.findIndex(s => !state.done.includes(s[0]) && (document.querySelector(s[0]) || (s[3] && document.querySelector(s[3]))));
    if (i >= 0) show(i);
  }
  // Steps wait for their controls: check now and then, and follow the page as it moves.
  setInterval(next, 1200);
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') { if (!state.off) { state.done = []; dismissed = false; } setTimeout(next, 400); }
    else close();
  });
  window.addEventListener('resize', () => { if (at >= 0) { const el = document.querySelector(steps[at][0]); if (visible(el)) place(el); else close(); } });
  document.addEventListener('scroll', () => { if (at >= 0) { const el = document.querySelector(steps[at][0]); if (visible(el)) place(el); } }, true);
  // ← in the top bar closes a note like any pop-up.
  const prevBack = window.__neededBack;
  window.__neededBack = () => { if (tip) { dismissed = true; close(); return true; } return prevBack ? prevBack() : false; };
  window.__neededHints = {
    replay() { state = { done: [] }; store(state); dismissed = false; close(); next(); },
    reset() { state = { done: [] }; store(state); },
  };
  setTimeout(next, 900);
})();
