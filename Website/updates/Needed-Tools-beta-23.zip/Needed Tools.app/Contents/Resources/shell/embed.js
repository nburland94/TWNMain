/* Needed Tools — what every tool gets inside the app:
   the apricot glow, full width at any window size, pop-ups that close
   when you click outside them, and ← closing whatever's open first. */
(function () {
  if (window.__neededEmbed) return;
  window.__neededEmbed = true;
  document.documentElement.classList.add('in-needed-tools');

  let css = `
    /* Round 54 — the same empty start on every tool: a cap, a line, one orange action */
    html.in-needed-tools .tstart{margin:14px 0;padding:34px 24px;border-radius:20px;border:1.5px dashed rgba(240,90,34,.42);background:radial-gradient(ellipse at 50% 15%,rgba(240,90,34,.07),rgba(240,90,34,0) 60%);text-align:center;display:flex;flex-direction:column;align-items:center;gap:10px}
    html.in-needed-tools .tstart[hidden]{display:none}
    html.in-needed-tools .tstart .ts-cap{font-family:'Courier Prime',monospace;font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:#d2440f}
    html.in-needed-tools .tstart h3{font-family:Oswald,sans-serif;font-weight:200;font-size:32px;line-height:1.1;margin:0;color:#1c1c1c}
    html.in-needed-tools .tstart p{font-size:13.5px;line-height:1.55;color:#6b6964;max-width:520px;margin:0}
    html.in-needed-tools .tstart .ts-go{margin-top:6px;height:38px;padding:0 18px;border-radius:100px;border:none;background:#F05A22;color:#fff;font:inherit;font-size:13.5px;font-weight:500;box-shadow:0 8px 22px rgba(240,90,34,.3);cursor:pointer}
    html[data-theme=dark].in-needed-tools body .tstart h3{color:#e6edf6}
    html[data-theme=dark].in-needed-tools body .tstart .ts-cap{color:#f07a4a}
    html[data-theme=dark].in-needed-tools body .tstart p{color:rgba(220,231,244,.66)}
    /* Round 56 — every place you drop something: the same orange-edged panel as Sort */
    html.in-needed-tools .tstart .ts-row{display:flex;gap:10px;justify-content:center;align-items:center;margin-top:6px}
    html.in-needed-tools .tstart .ts-row .ts-go{margin-top:0}
    html.in-needed-tools .tstart .ts-go:disabled{opacity:.45;cursor:default;box-shadow:none}
    html.in-needed-tools .tstart .ts-alt{height:38px;padding:0 18px;border-radius:100px;border:1px solid rgba(28,28,28,.14);background:rgba(255,255,255,.7);color:#1c1c1c;font:inherit;font-size:13.5px;font-weight:500;cursor:pointer;letter-spacing:normal;text-transform:none}
    html.in-needed-tools .tstart .ts-alt:disabled{opacity:.4;cursor:default}
    html[data-theme=dark].in-needed-tools body .tstart .ts-alt{background:rgba(255,255,255,.06);border-color:rgba(220,231,244,.16);color:#e6edf6}
    html.in-needed-tools .drop.tdrop{border:1.5px dashed rgba(240,90,34,.45)!important;border-radius:20px!important;padding:32px 24px!important;background:radial-gradient(ellipse at 50% 15%,rgba(240,90,34,.07),rgba(240,90,34,0) 60%)!important;display:flex;flex-direction:column;align-items:center;gap:10px;text-align:center}
    html.in-needed-tools .drop.tdrop.over{border-color:#F05A22!important;background:radial-gradient(ellipse at 50% 30%,rgba(240,90,34,.16),rgba(240,90,34,.03) 70%)!important}
    html.in-needed-tools .drop.tdrop .ts-cap{font-family:'Courier Prime',monospace;font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:#d2440f}
    html.in-needed-tools .drop.tdrop h3{font-family:Oswald,sans-serif;font-weight:200;font-size:32px;line-height:1.1;margin:0;color:#1c1c1c;letter-spacing:normal;text-transform:none}
    html.in-needed-tools .drop.tdrop .row{margin:6px 0 0!important}
    html.in-needed-tools .drop.tdrop #pickBtn{height:38px;padding:0 18px;border-radius:100px;border:none!important;background:#F05A22!important;color:#fff!important;font-family:Raleway,sans-serif!important;font-size:13.5px!important;font-weight:500;letter-spacing:normal!important;text-transform:none!important;box-shadow:0 8px 22px rgba(240,90,34,.3)}
    html.in-needed-tools .drop.tdrop p{font-size:13.5px!important;line-height:1.55;color:#6b6964!important;margin:0!important;max-width:520px}
    html[data-theme=dark].in-needed-tools body .drop.tdrop h3{color:#e6edf6}
    html[data-theme=dark].in-needed-tools body .drop.tdrop .ts-cap{color:#f07a4a}
    html[data-theme=dark].in-needed-tools body .drop.tdrop p{color:rgba(220,231,244,.66)!important}
    /* Round 57 — the Vault's link gets the same panel; Credit's paste box is soft glass */
    html.in-needed-tools .tlink{border:1.5px dashed rgba(240,90,34,.45);border-radius:20px;padding:30px 24px;background:radial-gradient(ellipse at 50% 15%,rgba(240,90,34,.07),rgba(240,90,34,0) 60%);display:flex;flex-direction:column;align-items:center;gap:10px;text-align:center}
    html.in-needed-tools .tlink .ts-cap{font-family:'Courier Prime',monospace;font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:#d2440f}
    html.in-needed-tools .tlink h3{font-family:Oswald,sans-serif;font-weight:200;font-size:32px;line-height:1.1;margin:0;color:#1c1c1c;letter-spacing:normal;text-transform:none}
    html.in-needed-tools .tlink .linkrow{width:100%;max-width:640px;justify-content:center;margin-top:6px}
    html.in-needed-tools .tlink .linkin{border-radius:100px!important;height:42px;padding:0 18px!important;border:1px solid rgba(28,28,28,.14)!important;background:rgba(255,255,255,.75)!important}
    html.in-needed-tools .tlink #lookupBtn{height:42px;padding:0 20px;border-radius:100px;border:none!important;background:#F05A22!important;color:#fff!important;font-family:Raleway,sans-serif!important;font-size:13.5px!important;font-weight:500;letter-spacing:normal!important;text-transform:none!important;box-shadow:0 8px 22px rgba(240,90,34,.3)}
    html.in-needed-tools .tlink p{font-size:13.5px;line-height:1.55;color:#6b6964;margin:0}
    html[data-theme=dark].in-needed-tools body .tlink h3{color:#e6edf6}
    html[data-theme=dark].in-needed-tools body .tlink .ts-cap{color:#f07a4a}
    html[data-theme=dark].in-needed-tools body .tlink p{color:rgba(220,231,244,.66)}
    html[data-theme=dark].in-needed-tools body .tlink .linkin{background:rgba(255,255,255,.06)!important;border-color:rgba(220,231,244,.16)!important;color:#e6edf6!important}
    html.in-needed-tools textarea#paste{border-radius:18px!important;border:1px solid rgba(28,28,28,.1)!important;background:linear-gradient(180deg,rgba(255,255,255,.72),rgba(255,255,255,.45))!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.9)!important;padding:14px 16px!important;font-family:Raleway,sans-serif!important;font-size:13.5px!important}
    html[data-theme=dark].in-needed-tools body textarea#paste{background:rgba(255,255,255,.04)!important;border-color:rgba(220,231,244,.12)!important;box-shadow:none!important;color:#e6edf6!important}
    /* Round 56 — your licence and Deactivate live in your account (top right), not at the foot of every tool */
    html.in-needed-tools #licFoot{display:none!important}
    /* Round 52 — one focus ring for every field, in its own current shape, by day and by night */
    html.in-needed-tools input:where(:not([type=checkbox]):not([type=radio]):not([type=range])):focus,
    html.in-needed-tools textarea:focus, html.in-needed-tools select:focus, html.in-needed-tools :where([contenteditable=true]):focus { outline: 1.5px solid #F05A22 !important; outline-offset: -1px !important; }
    html.in-needed-tools .sbox input:focus { outline: none !important; }
    /* table cells (Shots: the scene, the column names, each shot's fields): no old box — a thin orange line under the one you're in */
    html.in-needed-tools .sheet .shot textarea:focus, html.in-needed-tools .sheet .shot input:focus, html.in-needed-tools .sheet .shot select:focus,
    html.in-needed-tools .colname:focus, html.in-needed-tools .scenehead input:focus,
    html[data-theme=dark].in-needed-tools .sheet .shot textarea:focus, html[data-theme=dark].in-needed-tools .sheet .shot input:focus, html[data-theme=dark].in-needed-tools .sheet .shot select:focus,
    html[data-theme=dark].in-needed-tools .colname:focus, html[data-theme=dark].in-needed-tools .scenehead input:focus {
      outline: none !important; background: transparent !important; border-color: transparent !important; border-radius: 0 !important; box-shadow: inset 0 -1.5px 0 #F05A22 !important; }
    /* Round 52 — every switch in a tool sits in a glass container, as on Home */
    html.in-needed-tools .seg { padding: 3px; gap: 2px; border-radius: 100px; border: 1px solid rgba(255,255,255,0.7); background: linear-gradient(160deg, rgba(255,255,255,0.66), rgba(255,255,255,0.38)); -webkit-backdrop-filter: blur(30px) saturate(200%); backdrop-filter: blur(30px) saturate(200%); box-shadow: 0 6px 22px rgba(80,40,10,0.08), 0 1px 3px rgba(0,0,0,0.05); }
    html.in-needed-tools .seg button { border-radius: 100px; }
    html[data-theme=dark].in-needed-tools .seg { background: linear-gradient(180deg, rgba(255,255,255,0.10), rgba(255,255,255,0.03)) !important; border-color: rgba(255,255,255,0.14) !important; box-shadow: 0 8px 26px rgba(0,0,0,0.38) !important; }
    /* Round 52 — the vault, project and Grab & Go live in the top bar: not again on each tool */
    html.in-needed-tools .vaultloc > :not(#addToVault) { display: none !important; }
    html.in-needed-tools .vaultloc:not(:has(#addToVault)) { display: none !important; }
    html.in-needed-tools #projBlock > .opt:has(#destBtn), html.in-needed-tools #projBlock > .opt:has(#projSel) { display: none !important; }
    /* Round 49 — Blueprint: off-white with a calm orange glow by day, black with a calm blue one by night, a hairline grid over both */
    html.in-needed-tools { --bg: #f6f6f4; }
    html.in-needed-tools body { background: #f6f6f4; }
    html.in-needed-tools body::before { content: ''; position: fixed; inset: 0; z-index: -1; pointer-events: none; background-size: 48px 48px, 48px 48px, 100% 100%;
      background-image: linear-gradient(rgba(28,28,28,0.045) 1px,transparent 1px),linear-gradient(90deg,rgba(28,28,28,0.045) 1px,transparent 1px), radial-gradient(ellipse 62% 66% at 50% 48%, rgba(255,130,70,0.20), rgba(255,160,110,0.08) 55%, rgba(246,246,244,0) 80%); }
    html[data-theme=dark].in-needed-tools body { background: #030406 !important; }
    html[data-theme=dark].in-needed-tools body::before { background-image: linear-gradient(rgba(220,231,244,0.045) 1px,transparent 1px),linear-gradient(90deg,rgba(220,231,244,0.045) 1px,transparent 1px), radial-gradient(ellipse 62% 66% at 50% 48%, rgba(40,95,230,0.20), rgba(40,80,200,0.07) 55%, rgba(3,4,6,0) 80%) !important; }
    /* fill the window, however big it is */
    html.in-needed-tools main { max-width: none !important; }
    html.in-needed-tools body > header, html.in-needed-tools main, html.in-needed-tools .bar { padding-left: clamp(24px, 3vw, 56px) !important; padding-right: clamp(24px, 3vw, 56px) !important; }
    /* the bar along the bottom: glass over the glow */
    html.in-needed-tools .bar { background: rgba(246,246,244,0.82) !important; -webkit-backdrop-filter: blur(22px) saturate(1.5); backdrop-filter: blur(22px) saturate(1.5);
      border-top: 1px solid rgba(28,28,28,0.07) !important; }
    html[data-theme=dark].in-needed-tools .bar { background: rgba(3,4,6,0.82) !important; border-top-color: rgba(220,231,244,0.08) !important; }
    html.in-needed-tools header { background: transparent !important; border-bottom-color: rgba(28,28,28,0.06) !important; }
  `;
  // ---- a touch more contrast and gloss, same look
  css += `
    html.in-needed-tools { --ink: #141414; }
    html.in-needed-tools .pill { border-color: rgba(28,28,28,0.12); box-shadow: none; }
    html.in-needed-tools .pill.solid, html.in-needed-tools .pill.solid:disabled { background: linear-gradient(180deg, #2b2b2b, #111) !important; border-color: #111 !important;
      box-shadow: 0 2px 8px rgba(20,20,20,0.18); }
    html.in-needed-tools .chip.on { box-shadow: none; }
    html.in-needed-tools main input, html.in-needed-tools main textarea, html.in-needed-tools main select { box-shadow: none; }

    /* ---- players in the original's shape: no black box round a tall reel */
    html.in-needed-tools .stage { background: transparent !important; overflow: visible !important; }
    html.in-needed-tools .stage video { border-radius: 0; box-shadow: 0 18px 50px rgba(80,30,10,0.18), 0 0 0 0.5px rgba(0,0,0,0.12); background: #000; }
    html.in-needed-tools .pvstage { background: transparent !important; }
    html.in-needed-tools .pvstage canvas { border-radius: 10px; box-shadow: 0 14px 40px rgba(80,30,10,0.16); }

    /* ---- the Vault's viewer: the picture floating, details on glass */
    html.in-needed-tools #itemModal { background: rgba(251,243,237,0.3) !important; -webkit-backdrop-filter: blur(26px) saturate(1.3); backdrop-filter: blur(26px) saturate(1.3); }
    html.in-needed-tools #itemModal .itemwrap { background: transparent !important; box-shadow: none !important; border: none !important; }
    html.in-needed-tools #itemModal .itemmedia { background: transparent !important; min-height: 0 !important; overflow: visible !important; }
    html.in-needed-tools #itemModal .itemmedia img, html.in-needed-tools #itemModal .itemmedia video {
      border-radius: 0; box-shadow: 0 30px 90px rgba(0,0,0,0.28); max-height: 78vh; }
    html.in-needed-tools #itemModal .iteminfo {
      background: linear-gradient(160deg, rgba(255,255,255,0.62), rgba(255,255,255,0.34)); border: 1px solid rgba(255,255,255,0.7); border-radius: 20px;
      box-shadow: 0 24px 70px rgba(0,0,0,0.12); padding: 20px !important;
      -webkit-backdrop-filter: blur(30px) saturate(1.6); backdrop-filter: blur(30px) saturate(1.6); }

    /* no focus ring round the players — they still take the keyboard */
    html.in-needed-tools .stage, html.in-needed-tools .stage:focus, html.in-needed-tools .stage:focus-visible,
    html.in-needed-tools video:focus, html.in-needed-tools video:focus-visible, html.in-needed-tools .pvstage:focus,
    html.in-needed-tools canvas:focus, html.in-needed-tools [tabindex]:focus-visible.stage,
    html.in-needed-tools .stage.keys, html.in-needed-tools .pvstage.keys, html.in-needed-tools .pvstage:focus-within { outline: none !important; box-shadow: none !important; }
  `;
  const style = document.createElement('style');
  style.textContent = css;
  (document.head || document.documentElement).appendChild(style);

  const L = window.__neededLoad;             // the one loading pill (load.js)

  // Bringing a film in: how far along it is, until it's ready to scrub.
  const film = document.getElementById('video');
  if (film) {
    let loading = false;
    const buffered = () => { try { const d = film.duration; if (!d || !isFinite(d) || !film.buffered.length) return 0;
      return film.buffered.end(film.buffered.length - 1) / d; } catch (e) { return 0; } };
    film.addEventListener('loadstart', () => { if (!film.currentSrc && !film.src) return; if (!loading) { loading = true; L.start('Bringing it in'); } L.set(0.03); });
    film.addEventListener('loadedmetadata', () => loading && L.set(Math.max(0.35, buffered())));
    film.addEventListener('progress', () => loading && L.set(Math.max(0.35, buffered())));
    const end = () => { if (loading) { loading = false; L.done(); } };
    film.addEventListener('canplay', end);
    film.addEventListener('error', end);
    film.addEventListener('emptied', () => { if (loading && !film.src) end(); });
  }

  // Everything slow the tools ask the Mac to do shows the same pill.
  const SLOW = {
    lookup: 'Finding it', preview: 'Bringing it in', pull: 'Bringing it in', importFiles: 'Adding to your vault',
    makeGif: 'Making the GIF', makeClip: 'Making the MP4', vaultMove: 'Moving',
    scan: 'Scanning the cards', build: 'Copying and checking',
    exportPdf: 'Making the PDF', moodBoard: 'Making the mood board', previewPdf: 'Making the preview', importPdf: 'Reading the PDF', sendMail: 'Sending',
  };
  const handlers = window.webkit && window.webkit.messageHandlers;
  const files = handlers && handlers.files;

  // When one finishes, macOS says so — a notification, even if you're in another
  // app. Only on success; a sound too when it took a while.
  const plural = (n, one) => `${n} ${one}${n === 1 ? '' : 's'}`;
  const DONE = {
    preview: r => r && r.ok !== false && ['Footage is in', 'The link is ready to play and grab from.'],
    pull: r => r && r.ok && ['Footage is in', 'That section is ready in the Vault.'],
    importFiles: r => r && r.added && ['Added to your vault', `${plural(r.added, 'file')} added to this project.`],
    makeGif: r => r && r.ok && ['GIF saved', r.name || 'Saved into your project.'],
    makeClip: r => r && r.ok && ['MP4 saved', r.name || 'Saved into your project.'],
    scan: r => r && r.ok !== false && ['Cards scanned', 'Every clip is read and grouped into scenes.'],
    build: r => r && !r.cancelled && (r.failed && r.failed.length
      ? ['Sort finished — check it', `${r.copied} of ${r.total} copied; ${plural(r.failed.length, 'file')} didn't match the card.`]
      : ['Sort finished', `All ${r.copied} files copied and checked against the cards.`]),
    exportPdf: r => r && r.ok !== false && ['PDF made', r.name || 'Saved into your project.'],
    importPdf: r => r && r.ok !== false && ['Read it', 'The PDF is in.'],
    sendMail: (r, m) => r && r.ok && ['Sent', `${m && m.to ? 'To ' + m.to + ' — ' : ''}a copy is in your inbox.`],
    moodBoard: r => r && r.ok && ['Mood board saved', `${r.name} — ${plural(r.pages, 'page')}.`],
  };
  const shellBridge = handlers && handlers.shell;
  const tell = (title, body, sound) => { try { shellBridge && shellBridge.postMessage({ action: 'notify', title, body, sound: !!sound }); } catch (e) { /* fine */ } };
  // Stills save one file at a time: one notification for the batch, once it's quiet.
  let stillsSaved = 0, stillsT = null;
  const stillSaved = () => {
    stillsSaved++; clearTimeout(stillsT);
    stillsT = setTimeout(() => { tell('Stills saved', `${plural(stillsSaved, 'still')} saved into your project.`); stillsSaved = 0; }, 1500);
  };
  if (files && files.postMessage) {
    const send = files.postMessage.bind(files);
    try {
      files.postMessage = msg => {
        const action = msg && msg.action, label = SLOW[action];
        const p = send(msg);
        if (label && p && p.then) { L.start(label); p.then(() => L.done(), () => L.done()); }
        if (p && p.then && (DONE[action] || action === 'saveFile')) {
          const began = Date.now();
          p.then(r => {
            if (action === 'saveFile') {
              if (r && r.ok) { if (msg.folder === 'Sheets') tell('Contact sheet saved', r.name || 'Saved into your project.'); else stillSaved(); }
              return;
            }
            const said = DONE[action](r, msg);
            if (said) tell(said[0], said[1], Date.now() - began > 8000);
          }, () => {});
        }
        // jobs that report how far along they are (GIFs, MP4s, Sort's copying)
        if (action === 'progress' && p && p.then) p.then(r => {
          const f = r && (typeof r.progress === 'number' ? r.progress : typeof r.fraction === 'number' ? r.fraction : typeof r.pct === 'number' ? r.pct / 100 : null);
          if (f != null && L.busy) L.set(f);
        }, () => {});
        return p;
      };
    } catch (e) { /* this view won't let us watch — the tools still work, just without the pill */ }
  }

  // Pop-ups in the tools, and the button that closes each one.
  // (The Vault's idea editor is left out on purpose: a stray click shouldn't lose a half-written note.)
  const CLOSERS = [['cropModal', 'cropDone'], ['itemModal', 'itemClose'], ['drawer', 'drawerClose'], ['addModal', 'addCancel'], ['openModal', 'openCancel'], ['sendVeil', 'sCancel']];
  const openOne = () => {
    for (const [box, btn] of CLOSERS) {
      const el = document.getElementById(box);
      if (el && !el.hidden && getComputedStyle(el).display !== 'none') return [el, document.getElementById(btn)];
    }
    return null;
  };
  // Click the blur around a pop-up and it closes, same as its Done button —
  // and that click doesn't then land on whatever was underneath the pop-up.
  let swallowClick = false;
  document.addEventListener('mousedown', e => {
    const o = openOne();
    if (o && e.target === o[0] && o[1]) {
      e.preventDefault(); o[1].click();
      swallowClick = true; setTimeout(() => { swallowClick = false; }, 600);
    }
  }, true);
  document.addEventListener('click', e => {
    if (swallowClick) { swallowClick = false; e.stopPropagation(); e.preventDefault(); }
  }, true);
  // ← in the top bar closes what's open before going back a tab.
  window.__neededBack = () => {
    const o = openOne();
    if (o && o[1]) { o[1].click(); return true; }
    return false;
  };
})();

/* Round 62: no grey rules under the page headers or over the action bars — the grid is enough */
(function () {
  if (document.getElementById('nt-norules')) return;
  const st = document.createElement('style'); st.id = 'nt-norules';
  st.textContent = 'header{border-bottom:none!important;box-shadow:none!important} .bar,footer{border-top:none!important}';
  (document.head || document.documentElement).appendChild(st);
})();
